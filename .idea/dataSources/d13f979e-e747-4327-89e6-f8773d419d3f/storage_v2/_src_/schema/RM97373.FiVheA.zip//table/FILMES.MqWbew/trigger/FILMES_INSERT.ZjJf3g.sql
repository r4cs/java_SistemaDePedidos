create trigger FILMES_INSERT
    before insert
    on FILMES
    for each row
BEGIN
    SELECT filmes_id_seq.NEXTVAL INTO :NEW.ID FROM DUAL;
END;
/

