create PROCEDURE cadastrarMovimentacao( 
    p_mov_id IN NUMBER, 
    p_conta_id IN NUMBER, 
    p_tipo IN VARCHAR2, 
    p_valor IN NUMBER 
) AS 
    v_saldo_anterior NUMBER; 
    v_saldo_atual NUMBER; 
BEGIN 
    SELECT saldo INTO v_saldo_anterior 
    FROM ContaCorrente 
    WHERE ccor_id = p_conta_id; 

    v_saldo_atual := v_saldo_anterior + p_valor; 

    INSERT INTO Movimentacao(mov_id, conta_id, tipo, valor, saldo_anterior, saldo_atual) 
    VALUES (p_mov_id, p_conta_id, p_tipo, p_valor, v_saldo_anterior, v_saldo_atual); 

    UPDATE ContaCorrente 
    SET saldo = v_saldo_atual 
    WHERE ccor_id = p_conta_id; 

    DBMS_OUTPUT.PUT_LINE('Saldo atual: ' || v_saldo_atual); 
END;
/

