create PROCEDURE cadastraContaCorrente(
    p_ccor_id IN NUMBER,
    p_cliente_id IN NUMBER,
    p_tipo IN VARCHAR2,
    p_saldo in NUMBER
) AS
    --
BEGIN
    INSERT INTO ContaCorrente(ccor_id, cliente_id, tipo, saldo)
    VALUES(p_ccor_id, p_cliente_id, p_tipo, p_saldo);
END;
/

