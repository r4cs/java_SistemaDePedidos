create FUNCTION madia_notas (p1 IN NUMBER, p2 IN NUMBER, p3 IN NUMBER)
RETURN number
    IS
    media NUMBER;
BEGIN
    madia_notas := (p1 + p2 + p3)/3;
RETURN madia_notas;
end;
/

