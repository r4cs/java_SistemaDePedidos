create PROCEDURE 
    DELETE_cliente (P_codigo_cliente IN meus_clientes.codigo_cliente%TYPE)
IS
BEGIN
    DELETE FROM meus_clientes WHERE codigo_cliente=p_codigo_cliente;
END;
/

