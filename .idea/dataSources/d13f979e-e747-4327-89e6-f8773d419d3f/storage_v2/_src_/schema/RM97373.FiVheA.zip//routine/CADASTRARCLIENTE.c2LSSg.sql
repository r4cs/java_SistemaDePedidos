create PROCEDURE cadastrarCliente( 
    p_id IN NUMBER, 
    p_nome IN VARCHAR2, 
    p_cpf IN VARCHAR2, 
    p_endereco IN VARCHAR2, 
    p_telefone IN VARCHAR2 
) AS 
BEGIN 
    INSERT INTO Cliente (cliente_id, nome, cpf, endereco, telefone) 
    VALUES (p_id, p_nome, p_cpf, p_endereco, p_telefone); 
END;
/

