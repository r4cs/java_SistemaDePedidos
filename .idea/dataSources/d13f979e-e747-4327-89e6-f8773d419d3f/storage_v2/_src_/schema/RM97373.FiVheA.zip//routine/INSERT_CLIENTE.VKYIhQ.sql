create PROCEDURE insert_cliente (p_codigo_cliente IN meus_clientes.nome_cliente%TYPE,
                                            p_nome_cliente IN meus_clientes.nome_cliente%TYPE,
                                            p_cpf IN meus_clientes.cpf%TYPE,
                                            p_data_nasc IN meus_clientes.data_nasc%TYPE,
                                            p_sexo IN meus_clientes.sexo%TYPE,
                                            p_estado_civil IN meus_clientes.estado_civil%TYPE
                                            ) 
                                            IS
BEGIN                                            
        INSERT INTO meus_clientes (
            codigo_cliente,
            nome_cliente,
            cpf,
            data_nasc,
            sexo,
            estado_civil
        ) VALUES (
            p_codigo_cliente,
            p_nome_cliente,
            p_cpf,
            p_data_nasc,
            p_sexo,
            p_estado_civil
        );
    COMMIT;
END;
/

