create PROCEDURE PRC_EXCLUI_EMPREGADO(P_CODIGO IN employees.employee_id%TYPE) IS
BEGIN
    DELETE FROM EMPREGADOR WHERE CODIGO = P_CODIGO;
    COMMIT;
END;



/*genérico*/
CREATE OR REPLACE PROCEDURE meu_delete (P_CODIGO NUMBER) IS
BEGIN
    DELETE FROM aluno WHERE rm = p_codigo;
    COMMIT;
END;
/* PODE SER TB END meu_delete */




/* delete em aula */
CREATE OR REPLACE PROCEDURE MEU_DELETE (P_CODIGO IN countries.country_id) IS
BEGIN
    DELETE FROM cliente WHERE country_id = p_codigo;
    COMMIT;
END;    


CREATE TABLE countries2 AS SELECT * FROM countries WHERE 1 = 2;

CREATE OR REPLACE 
PROCEDURE insert_cliente (p_codigo_cliente IN meus_clientes.nome_cliente%TYPE,
                                            p_nome_cliente IN meus_clientes.nome_cliente%TYPE,
                                            p_cpf IN meus_clientes.cpf%TYPE,
                                            p_data_nasc IN meus_clientes.data_nasc%TYPE,
                                            p_sexo IN meus_clientes.sexo%TYPE,
                                            p_estado_civil IN meus_clientes.estado_civil%TYPE
                                            ) 
IS
    BEGIN                                            
        INSERT INTO meus_clientes (
            codigo_cliente,
            nome_cliente,
            cpf,
            data_nasc,
            sexo,
            estado_civil
        ) VALUES (
            p_codigo_cliente,
            p_nome_cliente,
            p_cpf,
            p_data_nasc,
            p_sexo,
            p_estado_civil
        );
    COMMIT;
END;    

EXEC INSERT_CLIENTE(1, 'Raquel', '4684468', '02/02/88', 'NB', 'CSD');



CREATE OR REPLACE 
PROCEDURE 
    delete_cliente (P_codigo_cliente IN meus_clientes.codigo_cliente%TYPE)
IS
BEGIN
    DELETE FROM meus_clientes WHERE codigo_cliente=p_codigo_cliente;
END;

EXEC delete_cliente(1);
/

