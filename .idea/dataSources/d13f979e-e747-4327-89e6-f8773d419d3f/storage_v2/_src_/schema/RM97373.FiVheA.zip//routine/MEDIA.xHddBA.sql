create FUNCTION media (p1 IN NUMBER, p2 IN NUMBER, p3 IN NUMBER)
    RETURN number
    IS
    total NUMBER;
BEGIN
    media := (p1 + p2 + p3)/3;
RETURN media;
end;
/

