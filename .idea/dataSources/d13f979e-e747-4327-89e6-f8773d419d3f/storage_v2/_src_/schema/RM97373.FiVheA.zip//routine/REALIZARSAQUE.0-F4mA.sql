create PROCEDURE realizarSaque(  
    p_conta_id IN NUMBER,  
    p_valor IN NUMBER 
) AS  
    v_tipo VARCHAR2(20); 
    v_saldo_atual NUMBER;  
    v_saldo_anterior NUMBER;  -- Declare a variável v_saldo_anterior
BEGIN 
    SELECT tipo INTO v_tipo 
    FROM ContaCorrente 
    WHERE ccor_id = p_conta_id; 

    SELECT saldo INTO v_saldo_atual  
    FROM ContaCorrente  
    WHERE ccor_id = p_conta_id;  

    -- Calcula o saldo anterior
    v_saldo_anterior := v_saldo_atual - p_valor;

    IF v_tipo = 'basico' THEN
        IF p_valor <= v_saldo_atual THEN  
            v_saldo_atual := v_saldo_atual - p_valor;  

            INSERT INTO Movimentacao (mov_id, conta_id, tipo, valor, saldo_anterior, saldo_atual)  
            VALUES (NULL, p_conta_id, 'D', p_valor, v_saldo_anterior, v_saldo_atual);  

            UPDATE ContaCorrente  
            SET saldo = v_saldo_atual  
            WHERE ccor_id = p_conta_id; 

            DBMS_OUTPUT.PUT_LINE('Saque realizado com sucesso!');  
            DBMS_OUTPUT.PUT_LINE('Saldo atual: ' || v_saldo_atual);  
        ELSE  
            DBMS_OUTPUT.PUT_LINE('Não é possível realizar o saque.');
        END IF;  
    ELSE
        IF p_valor <= v_saldo_atual OR p_valor <= (v_saldo_atual + (v_saldo_atual/2)) THEN
            v_saldo_atual := v_saldo_atual - p_valor;

            INSERT INTO Movimentacao(mov_id, conta_id, tipo, valor, saldo_anterior, saldo_atual)
            VALUES(NULL, p_conta_id, 'D', p_valor, v_saldo_anterior, v_saldo_atual);

            UPDATE ContaCorrente
            SET saldo = v_saldo_atual
            WHERE ccor_id = p_conta_id;

            DBMS_OUTPUT.PUT_LINE('Saque realizado com sucesso!');  
            DBMS_OUTPUT.PUT_LINE('Saldo atual: ' || v_saldo_atual);  
        ELSE
            DBMS_OUTPUT.PUT_LINE('Não é possível realizar o saque.');
        END IF;  
    END IF;  
END;
/

