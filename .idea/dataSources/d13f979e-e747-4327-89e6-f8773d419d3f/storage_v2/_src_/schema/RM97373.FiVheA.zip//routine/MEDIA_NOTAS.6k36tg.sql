create FUNCTION media_notas (p1 IN NUMBER, p2 IN NUMBER, p3 IN NUMBER)
RETURN number
    IS
    med NUMBER;
BEGIN
    med := (p1 + p2 + p3)/3;
RETURN med;
END;
/

